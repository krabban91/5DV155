CKEDITOR.plugins.setLang("pbckcode", "en",
{
    title    : 'PBCKCODE',
    addCode  : 'Add code',
    editCode : 'Edit code',
    editor   : 'Editor',
    settings : 'Settings',
    mode     : 'Mode',
    tabSize  : 'Tab size',
    theme    : 'Theme',
    softTab  : 'Enable soft tabs',
    emmet    : 'Enable Emmet'
});